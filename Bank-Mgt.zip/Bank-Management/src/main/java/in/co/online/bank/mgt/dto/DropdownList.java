package in.co.online.bank.mgt.dto;

/**
 * DropdownListBean Interface has Abstract Method
 * 
 * @author Navigable Set
 * @version 1.0
 * @Copyright (c) Navigable Set
 * 
 */
public interface DropdownList
{
	public String getKey();

	public String getValue();
}
